import './App.css';
import Recharge from './Components/Recharge';
import About from './Components/About';
import { Switch, Redirect, Route, BrowserRouter } from 'react-router-dom';
import Login from './Components/Login';
import NavBar from './Components/NavBar';
import Register from './Components/Register';
import ForgotPassword from './Components/ForgotPassword';
import DashBoard from './Components/DashBoard';
import DTHRecharge from './Components/DTHRecharge';
import { Button, Alert, Row, Col } from 'react-bootstrap';
import LoanRepayment from './Components/LoanPayment';
import TransferToBank from './Components/TransferToBank';
import TransferToUpiId from './Components/TransferToUpiId';
import ChangePassword from './Components/ChangePassword';
import LoanPayment from './Components/LoanPayment';
import Logout from './Components/Logout';
import DeleteAccount from './Components/DeleteAccount';
import OtpPage from './Components/OtpPage';
import Home from './Components/Home';
import LoanHistory from './Components/LoanHistory';
import BankHistory from './Components/BankHistory';
import UpiHistory from './Components/UpiHistory';
import DthHistory from './Components/DthHistory';
import MobileRecharge from './Components/MobileRecharge';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Switch>
          <Route exact path="/DashBoard" component={DashBoard}/>
          <Route path="/ForgotPassword/id" component={ForgotPassword} />
          <Route path="/Register" component={Register}/>
          <Route exact path="/About" component={About}/>
          <Route exact path="/LoanPayment/id" component={LoanPayment}/>
          <Route exact path="/DTHRecharge/id" component={DTHRecharge}/>
          <Route exact path="/TransferToBank/id" component={TransferToBank}/>
          <Route exact path="/TransferToUpiId/id" component={TransferToUpiId}/>
          <Route exact path="/ChangePassword/id" component={ChangePassword}/>
          <Route exact path="/" component={Login}/>
          <Route exact path="/Logout" component={Logout}/>
          <Route exact path="/Login" component={Login}/>
          <Route exact path="/Home" component={Home}/>
          <Route exact path="/OtpPage" component={OtpPage}/>
          <Route exact path="/DeleteAccount/id" component={DeleteAccount}/>
          <Route exact path="/LoanHistory/id" component={LoanHistory}/>
          <Route exact path="/BankHistory/id" component={BankHistory}/>
          <Route exact path="/UpiHistory/id" component={UpiHistory}/>
          <Route exact path="/DthHistory/id" component={DthHistory}/>
          <Route exact path="/MobileRecharge/id" component={MobileRecharge}/>
        </Switch>
      </BrowserRouter>

    </div>
  );
}

export default App;
