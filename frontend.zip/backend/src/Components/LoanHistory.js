import React, { Component, useState } from 'react';
import {Table, thead, tbody} from 'react-bootstrap';

class LoanHistory extends Component {
    constructor(props) {
        super(props);
        this.state = {
            list: [],
        }
    }
    componentDidMount() {
        var id=localStorage.getItem("this.state.Id")
        fetch(`https://localhost:44392/api/recharges/loanhistory/${id}`).then((response) => {
            response.json().then((result) => {
                console.log(result);
                this.setState({ list: result })
                console.log(this.state.list)
            })
        })
    }
    render() {
        console.log(localStorage.getItem("this.state.Id"))
        console.log(this.state.list);
        return (
            <div style={{backgroundImage: "url('./img/bg.png')" }}>
                <h1>Loan History</h1>
                <Table>
                    <thead>
                        <tr>
                            <th>SI.No.</th>
                            <th>Policy Number</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.list.map((item,i) => {
                                return <tr key={i}>
                                    <td>{i+1}</td>
                                    <td>{item.PolicyNumber}</td>
                                    <td>{item.Money}</td>
                                </tr>
                            })
                        }
                    </tbody>
                </Table>
            </div>
        );
    }
}

export default LoanHistory;