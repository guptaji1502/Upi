import React, { Component } from 'react';

class Recharge extends Component {
    render() {
        return (
            <>
            <div className='rechargedesign'>
                <form>
                    <div className="htmlForm-group">
                        
                        <label htmlFor="MobileNumber">Mobile Number</label>
                        <input type="tel" className="htmlForm-control" id="MobileNumber" placeholder="Enter mobile number" />
                    </div>
                    <div>
                        <label>Network Circle</label>
                        <select className="htmlForm-group">
                            <option>Chennai</option>
                            <option>Delhi NCR</option>
                            <option>Kolkata</option>
                            <option>Mumbai</option>
                            <option>Maharashtra & Goa</option>
                            <option>Assam</option>
                            <option>Bihar & Jharkhand</option>
                            <option>Gujarat</option>
                            <option>Haryana</option>
                            <option>Himachal Pradesh</option>
                            <option>Jummu & Kashmir</option>
                            <option>Karnataka</option>
                            <option>Kerala</option>
                            <option>Andhra Pradesh</option>
                            <option>MP & Chattisgarh</option>
                            <option>North East</option>
                            <option>Orissa</option>
                            <option>Punjab</option>
                            <option>Rajasthan</option>
                            <option>Tamilnadu</option>
                            <option>UP East</option>
                            <option>UP West & Utterkhand</option>
                            <option>West Bengal</option>
                        </select>
                    </div>
                    <div>
                        <label>Service Provider</label>
                        <select className="htmlForm-group">
                            <option>choose service...</option>
                            <option>Jio</option>
                            <option>Airtel</option>
                            <option>BSNL</option>
                        </select>
                    </div>

                    <div className="htmlForm-group">
                        <label htmlFor="Money">Amount</label>
                        <input type="text" className="htmlForm-control" id="Amount" placeholder="Amount" />
                    </div>
                    <div className="htmlForm-group">
                        <label htmlFor="Remarks">Remarks</label>
                        <input type="text" className="htmlForm-control" id="Remarks" placeholder="Remarks(Optional)" />
                    </div>



                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
                </div>
            </>
        );
    }
}

export default Recharge;