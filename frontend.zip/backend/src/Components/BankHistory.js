import React, { Component, useState } from 'react';
import {Table, thead, tbody} from 'react-bootstrap';

class BankHistory extends Component {
    constructor(props) {
        super(props);
        this.state = {
            list: []
        }
    }
    componentDidMount() {
        var id = localStorage.getItem("this.state.Id")
        fetch(`https://localhost:44392/api/recharges/bankhistory/${id}`).then((response) => {
            response.json().then((result) => {
                console.log(result);
                this.setState({ list: result })
                console.log(this.state.list)
            })
        })
    }
    render() {
        console.log(localStorage.getItem("this.state.Id"))
        console.log(this.state.list);
        return (
            <div style={{backgroundImage: "url('./img/bg.png')" }}>
                <h1>Bank Transfer History</h1>
                <Table>
                    <thead>
                        <tr>
                            <th>SI.No.</th>
                            <th>Account Number</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.list.map((item,i) => {
                                return <tr key={i}>
                                    <td>{i+1}</td>
                                    <td>{item.AccountNumber}</td>
                                    <td>{item.Money}</td>
                                </tr>
                            })
                        }
                    </tbody>
                </Table>
            </div>
        );
    }
}

export default BankHistory;