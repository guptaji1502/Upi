import React, { Component } from 'react';
import { Button, Form, FormLabel } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';


class TransferToBank extends Component {
  constructor(props) {
    super(props);
    this.state = {
      AccountNumber: '',
      IFSC:'',
      Money: '',
      Remarks: ''
    }
    this.AccountNumber = this.AccountNumber.bind(this);
    this.IFSC=this.IFSC.bind(this);
    this.Money = this.Money.bind(this);
    this.Remarks = this.Remarks.bind(this);
    this.bank = this.bank.bind(this);
  }

  AccountNumber(event) {
    this.setState({ AccountNumber: event.target.value })
  }
  IFSC(event){
    this.setState({ IFSC : event.target.value})
  }
  Money(event) {
    this.setState({ Money: event.target.value })
  }
  Remarks(event) {
    this.setState({ Remarks: event.target.value })
  }


  bank(event) {
    var id = localStorage.getItem("this.state.Id")
    console.log(id);
    fetch(`https://localhost:44392/api/recharges/transfertobank/${id}`, {
      method: 'post',
      mode: 'cors',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token'
      },
      body: JSON.stringify({
        AccountNumber: this.state.AccountNumber,
        IFSC:this.state.IFSC,
        Money: this.state.Money,
        Remarks: this.state.Remarks,

      })
    }).then((response) => {
      if (response.status === 200) {

        console.log(response.json());
        alert('Money transfered Successfully');
        window.location.href = "/dashboard";
      }
      else {
        console.log("something went wrong");
      }
    }).catch((error) => {

      console.log(error);
    });
  }



  render() {
    console.log(localStorage.getItem("this.state.Id"));
    return (

      <div className="parent" style={{backgroundImage: "url('./img/bg.png')" }}>

        <h2>Bank Transfer</h2><br />
        <Form style={{ width: "50%", marginLeft: "25%", marginBottom: "10%", marginTop: "1%" }} className='form-container' >
          <Form.Group >
            <FormLabel style={{ width: "50%", marginBottom: "5%" }}>
              <Form.Control type='number' placeholder='Account number' id="AccountNumber" onChange={this.AccountNumber} />
            </FormLabel>
          </Form.Group>
          <Form.Group >
            <FormLabel style={{ width: "50%", marginBottom: "5%" }}>
              <Form.Control type='text' placeholder='IFSC' id="IFSC" onChange={this.IFSC} />
            </FormLabel>
          </Form.Group>
          <Form.Group>
            <FormLabel style={{ width: "50%" }}>
              <Form.Control type='decimal' placeholder='Amount' id="Money" onChange={this.Money} />
            </FormLabel>
          </Form.Group>
          <br />

          <Form.Group>
            <FormLabel style={{ width: "50%", marginTop: "1%" }}>
              <textarea
                className="form-control"
                rows="5" placeholder='Remarks(Optional)' id="Remarks" onChange={this.Remarks}
              />
            </FormLabel>
          </Form.Group>
          <br />
          <Button style={{ width: "50%" }} onClick={this.bank} type='submit'>Submit</Button>


        </Form>
      </div>
    );
  }
}


export default withRouter(TransferToBank);
