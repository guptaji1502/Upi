import React, { Component } from 'react';
import { Button, Form, FormLabel } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';

class OtpPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            PassWord: '',
            otp: ''
        }
        this.PassWord = this.PassWord.bind(this);
        this.otp = this.otp.bind(this);
        this.forgot = this.forgot.bind(this);
    }

    PassWord(event) {
        this.setState({ PassWord: event.target.value })
    }
    otp(event) {
        this.setState({ otp: event.target.value })
    }



    forgot(event) {
        var id = localStorage.getItem("this.state.Id")
        var Otp = localStorage.getItem("this.state.otp")
        console.log(id);
        console.log(Otp);
        fetch(`https://localhost:44392/api/authusers/forgotpassword/${id}`, {
            method: 'POST',
            mode: 'cors',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token'
            },
            body: JSON.stringify({

                
                PassWord: this.state.PassWord,
                otp: this.state.otp

            })
        }).then((response) => {
            if (response.status === 200)
                return response.json();
        }).then((data) => {
            // console.log("User Logged in Successfully");
            //this.state.otp = data[0];
            // localStorage.setItem("this.state.otp", this.state.otp);
            if (this.state.otp === Otp) {
                
                alert("Wrong otp")
            }
            else {
                
                alert("Password reset successfully");
                window.location.href = "/login";
            }
        }).catch((error) => {

            console.log(error);
        });
    }


    render() {
        console.log(localStorage.getItem("this.state.Id"));
        return (

            <div className="parent" style={{backgroundImage: "url('./img/bg.png')" }}>

                <h2>Reset Password</h2><br />
                <Form style={{ width: "50%", marginLeft: "25%", marginBottom: "10%", marginTop: "1%" }} className='form-container' >


                    <Form.Group>
                        <FormLabel style={{ width: "150%" }}>
                            <Form.Control type='password' id="PassWord" onChange={this.PassWord} placeholder='Enter new Password' autoComplete='on' style={{ width: "65%" }} />
                        </FormLabel>
                    </Form.Group>
                    <Form.Group>
                        <FormLabel style={{ width: "50%", marginTop: "1%" }}>
                            <Form.Control type='text' placeholder='4-Digit OTP' id="otp" onChange={this.otp} />
                        </FormLabel>
                    </Form.Group>
                    <br />

                    <Button style={{ width: "50%" }} onClick={this.forgot} type='submit'>Reset</Button>


                </Form>
            </div>
        );
    }
}


export default withRouter(OtpPage);