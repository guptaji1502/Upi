import React, { Component } from 'react';
import { Button, Form, FormLabel } from 'react-bootstrap';
import {withRouter} from 'react-router-dom';

class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      FirstName: '',
      LastName: '',
      MobileNumber: '',
      Email: '',
      PassWord: '',
      isRegistered: false

    }

    this.FirstName = this.FirstName.bind(this);
    this.LastName = this.LastName.bind(this);
    this.MobileNumber = this.MobileNumber.bind(this);
    this.Email = this.Email.bind(this);
    this.PassWord = this.PassWord.bind(this);
    this.register = this.register.bind(this);
  }

  FirstName(event) {
    this.setState({ FirstName: event.target.value })
  }
  LastName(event) {
    this.setState({ LastName: event.target.value })
  }
  MobileNumber(event) {
    this.setState({ MobileNumber: event.target.value })
  }
  Email(event) {
    this.setState({ Email: event.target.value })
  }
  PassWord(event) {
    this.setState({ PassWord: event.target.value })
  }
  

  register(event) {

    fetch('https://localhost:44392/api/authusers/userregister', {
      method: 'post',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        FirstName: this.state.FirstName,
        LastName: this.state.LastName,
        MobileNumber: this.state.MobileNumber,
        Email: this.state.Email,
        PassWord: this.state.PassWord,

      })
    }).then((response) => {
      if (response.status === 200){
        alert('Registered');
      console.log(response.json());
      window.location.href = "/Login";}
      else{
      console.log("something went wrong");}
    })
  }

  render() {
    return (
      <div className="parent" style={{ backgroundImage: "url('./img/home.png')", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>
        <h1 style={{color: "white"}}>Create a new Account</h1>
       
        <div className="child" >
        
          <Form style={{ width: "150%", marginLeft: "10%", marginRight: "20%", marginBottom: "20%" }} className='form-container' >
            <Form.Group>
              <FormLabel style={{ width: "98%" ,marginLeft: "9%"}}>
                <Form.Control type='text' id="FirstName" onChange={this.FirstName} placeholder='Enter First Name' size='80' style={{ width: "85%" }} />
              </FormLabel>
            </Form.Group>
            <Form.Group>
              <FormLabel style={{ width: "98%" ,marginLeft: "9%"}}>
                <Form.Control type='text' id="LastName" onChange={this.LastName} placeholder='Enter Last Name' size='80' style={{ width: "85%" }} />
              </FormLabel>
            </Form.Group>
            <Form.Group>
              <FormLabel style={{ width: "98%" ,marginLeft: "9%"}}>
                <Form.Control type='tel' id="MobileNumber" onChange={this.MobileNumber} placeholder='Enter Mobile Number' size='80' style={{ width: "85%" }} />
              </FormLabel>
            </Form.Group>
            <Form.Group>
              <FormLabel style={{ width: "98%" ,marginLeft: "9%"}}>
                <Form.Control type='email' id="Email" onChange={this.Email} placeholder='Enter Email' size='80' style={{ width: "85%", paddingBottom:"4%" }} />
              </FormLabel>
            </Form.Group>
            <Form.Group style={{marginTop:"2%"}}>
              <FormLabel style={{ width: "98%" ,marginLeft: "9%"}}>
                <Form.Control type='password' id="PassWord" onChange={this.PassWord} placeholder='Enter Password' autoComplete='on' style={{ width: "85%" , paddingBottom:"4%"}} />
              </FormLabel>
            </Form.Group>
            <Button style={{ width: "85%",marginTop:"2%" }} onClick={this.register} type='submit'>Register</Button>
          </Form>
        </div>
      </div>
    );

  }
}

export default Register;