import React, { Component, useState } from 'react';
import { Button, Form, FormLabel } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';

export class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Email: '',
      PassWord: '',
      isLoggedIn: false,
      Id: '',
    }
    this.Email = this.Email.bind(this);
    this.PassWord = this.PassWord.bind(this);
    this.login = this.login.bind(this);
  }

  Email(event) {
    this.setState({ Email: event.target.value })
  }
  PassWord(event) {
    this.setState({ PassWord: event.target.value })
  }

  login(event) {


    fetch('https://localhost:44392/api/authusers/userlogin', {
      method: 'post',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        Email: this.state.Email,
        PassWord: this.state.PassWord,
      })
    }).then((response) => {
      if (response.status === 200)
        return response.json();
    })
      .then((data) => {
        this.setState({ isLoggedIn: true });
        console.log(this.state.isLoggedIn);
        console.log("User Logged in Successfully");
        this.state.Id = data[0];
        console.log(this.state.Id);
        localStorage.setItem("this.state.Id", this.state.Id);


        this.props.history.push("/DashBoard")
      })



    //else{
    //alert("User entered wrong credentials");
    //})
  }

  render() {
    return (
      <>
        <div className="parent" style={{ backgroundImage: "url('./img/home.png')", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>
          <h1 style={{ color: "white" }}>Welcome To VPE</h1>

          <div className="child">
            <Form style={{ width: "130%", marginLeft: "10%", marginRight: "20%", marginBottom: "10%",marginTo:"10%" }} className='form-container' >
              <Form.Group>
                <FormLabel style={{ width: "150%" }}>
                  <Form.Control type='email' id="Email" onChange={this.Email} placeholder='Enter Email address' size='80' style={{ width: "65%", marginTop: "10%" }} />
                </FormLabel>
              </Form.Group>
              <br />

              <Form.Group>
                <FormLabel style={{ width: "150%" }}>
                  <Form.Control type='password' id="PassWord" onChange={this.PassWord} placeholder='Enter Password' autoComplete='on' style={{ width: "65%" }} />
                </FormLabel>
              </Form.Group>
              <br />
              <Button style={{ width: "82%" }} onClick={this.login}>Login</Button><br />
              <a href="/ForgotPassword/id">Forgot Password?</a><br></br>
              <a href="/Register">Don't have account?</a><br></br>

            </Form>
          </div>
        </div>
      </>
    );
  }
}



export default withRouter(Login);
