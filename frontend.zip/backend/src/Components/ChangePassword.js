import React, { Component } from 'react';
import { Button, Form, FormLabel } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';


class ChangePassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      PassWord: ''
    }
    this.PassWord = this.PassWord.bind(this);
    this.changePassWord = this.changePassWord.bind(this);
  }

  PassWord(event) {
    this.setState({ PassWord: event.target.value })
  }


  changePassWord(event) {
    var id = localStorage.getItem("this.state.Id")
    console.log(id);
    fetch(`https://localhost:44392/api/authusers/changepassword/${id}`, {
      method: 'put',
      mode: 'cors',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token'
      },
      body: JSON.stringify({
        PassWord: this.state.PassWord,

      })
    }).then((response) => {
      if (response.status === 200) {

        console.log(response.json());
        alert('Password changed Successfully');
        window.location.href = "/dashboard";
      }
      else {
        console.log("something went wrong");
      }
    }).catch((error) => {

      console.log(error);
    });
  }



  render() {
    console.log(localStorage.getItem("this.state.Id"));
    return (

      <div className="parent" style={{backgroundImage: "url('./img/bg.png')" }}>

        <h2>Change Password</h2><br />
        <Form style={{ width: "50%", marginLeft: "25%", marginBottom: "10%", marginTop: "1%" }} className='form-container' >
          <Form.Group >
            <FormLabel style={{ width: "50%", marginBottom: "5%" }}>
              <Form.Control type='text' placeholder='Enter new Password' id="PassWord" onChange={this.PassWord} />
            </FormLabel>
          </Form.Group>

          <br />
          <Button style={{ width: "50%" }} onClick={this.changePassWord} type='submit'>Submit</Button>


        </Form>
      </div>
    );
  }
}


export default withRouter(ChangePassword);
