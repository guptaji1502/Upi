import React,{Component} from 'react';
import Carousel from 'react-bootstrap/Carousel'
import { Nav, NavDropdown, Navbar, Container, Offcanvas, Form, FormControl, Button } from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.css";

class Dashboard extends Component {
  render(){
    console.log(localStorage.getItem("this.state.Id"));
  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container>
          <Navbar.Brand style={{ marginRight: "2%" }} href="#home">
            <img
              alt=" "
              src="./img/LOGO.png"
              width="60"
              height="50"
              className="d-inline-block align-top"
            />{' '}
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto" >
              <Nav.Link style={{ marginRight: "2%" }} href="/Home">Home</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/TransferToUpiId/id">UPI ID Transfer</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/TransferToBank/id">Bank Transfer</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/MobileRecharge/id">Mobile Recharge</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/DTHRecharge/id">DTH Recharge</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/LoanPayment/id">Loan Payment</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/ChangePassword/id">Change Password</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/About">About</Nav.Link>
              <NavDropdown title="Contact Us" id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Coustomer Care</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">Feedback</NavDropdown.Item>
              </NavDropdown>
              <Nav.Link style={{ marginRight: "2%" }} href="/DeleteAccount/id">Delete Account</Nav.Link>
              <Nav.Link style={{ marginRight: "2%" }} href="/Logout">Logout</Nav.Link>
            </Nav>

          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Carousel style={{ width: "100%", height: "" }}>
        <Carousel.Item interval={700}>
          <img
            className="d-block w-100"
            src="./img/MobileRecharge.png"
            alt="Slide 2"
          />
          <Carousel.Caption>
            <h3>Recharge</h3>
            <p>Easy Mobile Recharge</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={700}>
          <img
            className="d-block w-100"
            src="./img/LoanPayment.png"
            alt="Slide 2"
          />
          <Carousel.Caption>
            <h3>Loan</h3>
            <p>Easy loan payments</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={700}>
          <img
            className="d-block w-100"
            src="./img/DTHRecharge.png"
            alt="Slide 3"
          />
          <Carousel.Caption>
            <h3>Recharge</h3>
            <p>Easy DTH recharge</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    </div>
  )
}
}

export default Dashboard;
