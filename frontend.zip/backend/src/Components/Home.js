import React, { Component } from 'react';
import { Container, Image } from 'react-bootstrap';
import { Link } from 'react-router-dom';

class Home extends Component {
    render() {
        return (
            <div >
                <Container>
                    <h1>Transaction History</h1>
                    <div>
                        <figure>
                            <a href="/BankHistory/id">
                                <img alt="Unable to download" src="./img/BankLogo.png" style={{ border: "1px solid black" }}
                                    width="200" height="150" /></a>
                            <figcaption>Bank Transfer History</figcaption>
                        </figure>
                        <figure>
                            <a href="/UpiHistory/id">
                                <img alt="Unable to download" src="./img/upilogo.png" style={{ border: "1px solid black" }}
                                    width="200" height="150" /></a>
                            <figcaption>UPI transfer History</figcaption>
                        </figure>
                    </div>
                    <br />
                    <div>
                        <figure>
                            <a href="/LoanHistory/id">
                                <img alt="Unable to download" src="./img/loanlogo.png" style={{ border: "1px solid black" }}
                                    width="200" height="150" /></a>
                            <figcaption>Loan History</figcaption>
                        </figure>
                        <figure>
                            <a href="/DthHistory/id">
                                <img alt="Unable to download" src="./img/DthLogo.png" style={{ border: "1px solid black" }}
                                    width="200" height="150" />

                            </a>
                            <figcaption>DTH History</figcaption>
                        </figure>
                    </div>
                </Container>
            </div>
        );
    }
}

export default Home;