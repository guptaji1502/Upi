import React, { Component } from 'react';
export default class Logout extends Component {
 
 yeslogout = () => {
    localStorage.clear();
    window.location.href = "/";
  }
  nologout = () => {
    localStorage.clear();
    window.location.href = "/dashboard";
  }
 
  render() {
    return (
        <div><br></br><br></br><br></br>
            <p>Are you sure you want to exit?</p>
            <button onClick={this.nologout}>No</button>

      <button onClick={this.yeslogout}>Yes</button>
      </div>
    )
  }
}