import React, { Component } from 'react';
import { Button, Form, FormLabel } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';


class ForgotPassword extends Component {
    constructor(props) {
        super(props);
        this.state = {
            FirstName: '',
            Email: '',
            Otp: ''
        }
        this.FirstName = this.FirstName.bind(this);
        this.Email = this.Email.bind(this);
        this.sendOtp = this.sendOtp.bind(this);
    }

    FirstName(event) {
        this.setState({ FirstName: event.target.value })
    }
    Email(event) {
        this.setState({ Email: event.target.value })
    }


    sendOtp(event) {
        var id = localStorage.getItem("this.state.Id")
        fetch(`https://localhost:44392/api/authusers/sendotp/${id}`, {
            method: 'post',
            mode: 'cors',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token'
            },
            body: JSON.stringify({
                FirstName: this.state.FirstName,
                Email: this.state.Email,

            })
        }).then((response) => {
            if (response.status === 200)
                return response.json();
        }).then((data) => {
            // console.log("User Logged in Successfully");
            //console.log(data)
            //this.state.Otp = data[0];
            //console.log(this.state.Otp);
            //localStorage.setItem("this.state.otp", this.state.otp);
            alert("Otp sent to your Email Id");
            //console.log(data);
            this.state.Otp = data;
            localStorage.setItem("this.state.Otp", this.state.Otp);
            console.log(this.state.Otp);
            window.location.href = "/otppage";
            //window.location.href = "/OtpPage"
            //if(this.state.otp === this.enteredotp){
            //alert("Otp sent to your Email Id")
            //window.location.href = "/OtpPage"
        }).catch((error) => {

            console.log(error);
        });
    }




    render() {
        console.log(localStorage.getItem("this.state.Id"));
        return (
            <>
                <div className='parent' style={{ backgroundImage: "url('./img/home.png')", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>


                    <h2>Forgot Password</h2><br />
                    <Form style={{ width: "50%", marginLeft: "25%", marginBottom: "10%", marginTop: "1%" }} className='form-container' >
                        <Form.Group >
                            <FormLabel style={{ width: "60%", marginBottom: "5%" }}>
                                <Form.Control type='text' placeholder='First Name' id="FirstName" onChange={this.FirstName} />
                            </FormLabel>
                        </Form.Group>

                        <Form.Group>
                            <FormLabel style={{ width: "70%", marginleft: "10%" }}>
                                <Form.Control type='email' placeholder='Email' id="Email" style={{ marginleft: "10%" }} onChange={this.Email} />
                            </FormLabel>
                        </Form.Group>
                        <br />
                        <Button style={{ width: "50%" }} onClick={this.sendOtp} >Send OTP</Button>
                    </Form>
                </div>

            </>
        );
    }
}


export default withRouter(ForgotPassword);
