import React,{Component} from 'react';
import { Nav, NavDropdown, Navbar, Container, Offcanvas, Form, FormControl, Button } from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.css";


class NavBar extends Component {
  render() {
    return (
      <>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Container>
        <Navbar.Brand style={{ marginRight: "2%" }} href="#home">
          <img
            alt=" "
            src="./img/LOGO.png"
            width="60"
            height="50"
            className="d-inline-block align-top"
          />{' '}
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto" >
            <Nav.Link style={{ marginRight: "3%" }} href="#Home">Home</Nav.Link>
            <Nav.Link style={{ marginRight: "3%" }} href="#Create UPI ID Transfer">UPI ID Transfer</Nav.Link>
            <Nav.Link style={{ marginRight: "3%" }} href="#Create Bank ID Transfer">Bank Transfer</Nav.Link>
            <Nav.Link style={{ marginRight: "3%" }} href="#Recharge">Mobile Recharge</Nav.Link>
            <Nav.Link style={{ marginRight: "3%" }} href="#Recharge">DTH Recharge</Nav.Link>
            <Nav.Link style={{ marginRight: "3%" }} href="#Loan Payment">Loan Payment</Nav.Link>
            <Nav.Link style={{ marginRight: "3%" }} href="#Changepassword">Change Password</Nav.Link>
            <Nav.Link style={{ marginRight: "3%" }} href="#About">About</Nav.Link>
            <NavDropdown title="Contact Us" id="collasible-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">Coustomer Care</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">Mail</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Feedback</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4"></NavDropdown.Item>
            </NavDropdown>
          </Nav>

        </Navbar.Collapse>
      </Container>
    </Navbar>

    </>
    );
  }
}

export default NavBar;