import React, { useEffect, useState } from 'react';

function DeleteAccount() {
    function dontdelete() {
        localStorage.clear();
        window.location.href = "/dashboard";
      }
      function yesdelete(event) {
        var id = localStorage.getItem("this.state.Id")
        console.log(id);
          fetch(`https://localhost:44392/api/authusers/deleteaccount/${id}`,{
              method:'DELETE',
              headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': "*",
                'Access-Control-Allow-Methods': "*"
              }
          }).then((response) => {
            if (response.status === 200)
              return response.json();
          })
            .then((data) => {
              alert("Account deleted successfully")
              window.location.href = "/login";
      });
    }
   
    return (
        <div style={{backgroundImage: "url('./img/bg.png')" }}><br></br><br></br><br></br>
            <p>Are you sure you want to delete?</p>
            <button onClick={dontdelete}>No</button>

            <button onClick={yesdelete}>Yes</button>
        </div>
    );
}

export default DeleteAccount;
